package com.example.post.aws;

import com.amazonaws.regions.Regions;

public class AWSKeys {
    protected static final String COGNITO_POOL_ID = "ap-northeast-2:44d69883-49d2-4586-9c13-465f3e9cd278";
    protected static final Regions MY_REGION = Regions.AP_NORTHEAST_2; /*Change Region Here*/
    public static final String BUCKET_NAME = "sikigobucket";

}
