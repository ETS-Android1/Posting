package com.example.post;

import androidx.appcompat.app.AppCompatActivity;

public class MakePost extends AppCompatActivity {
}
